jar cfm Run.jar MANIFEST.MF -C src . (empacota os .class em .jar)

javac src/*.java (compila)
