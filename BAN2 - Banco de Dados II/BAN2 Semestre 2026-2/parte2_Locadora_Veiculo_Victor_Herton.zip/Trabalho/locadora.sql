
CREATE TABLE IF NOT EXISTS Status (
    id_status SERIAL PRIMARY KEY,
    descricao VARCHAR(128) NOT NULL
);

CREATE TABLE IF NOT EXISTS Agencia (
    id_agencia SERIAL PRIMARY KEY,
    cod_agencia VARCHAR(64) NOT NULL UNIQUE,
    nome_agencia VARCHAR(128) NOT NULL,
    cidade VARCHAR(128) NOT NULL,
    endereco VARCHAR(255) NOT NULL,
    telefone_agencia VARCHAR(32) NOT NULL
);

CREATE TABLE IF NOT EXISTS Cliente (
    id_cliente SERIAL PRIMARY KEY,
    nome VARCHAR(128) NOT NULL,
    endereco VARCHAR(255) NOT NULL,
    email VARCHAR(128) NOT NULL,
    telefone VARCHAR(32) NOT NULL
);

CREATE TABLE IF NOT EXISTS Adicional (
    id_adicional SERIAL PRIMARY KEY,
    descricao_adicional VARCHAR(128) NOT NULL,
    valor_diaria NUMERIC(10, 2) NOT NULL
);


CREATE TABLE IF NOT EXISTS Fisica (
    id_cliente INTEGER PRIMARY KEY REFERENCES Cliente(id_cliente) ON DELETE CASCADE,
    cpf VARCHAR(14) NOT NULL UNIQUE, 
    rg VARCHAR(20) NOT NULL,
    cnh VARCHAR(20) NOT NULL UNIQUE, 
    data_nascimento DATE NOT NULL
);

CREATE TABLE IF NOT EXISTS Juridica (
    id_cliente INTEGER PRIMARY KEY REFERENCES Cliente(id_cliente) ON DELETE CASCADE,
    cnpj VARCHAR(18) NOT NULL UNIQUE, 
    razao_social VARCHAR(128) NOT NULL,
    inscricao_estadual VARCHAR(32) NOT NULL
);


CREATE TABLE IF NOT EXISTS Frota (
    id_frota SERIAL PRIMARY KEY,
    quantidade_veiculos INTEGER NOT NULL DEFAULT 0,
    id_agencia INTEGER NOT NULL REFERENCES Agencia(id_agencia) ON DELETE RESTRICT 
);

CREATE TABLE IF NOT EXISTS Veiculo (
    id_veiculo SERIAL PRIMARY KEY,
    placa VARCHAR(10) NOT NULL UNIQUE, 
    marca VARCHAR(64) NOT NULL,
    cor VARCHAR(64) NOT NULL,
    ano_fabricacao INTEGER NOT NULL,
    capacidade_passageiros INTEGER NOT NULL,
    tipo_combustivel VARCHAR(64) NOT NULL,
    categoria VARCHAR(64) NOT NULL,
    quilometragem_atual INTEGER NOT NULL DEFAULT 0,
    id_status INTEGER NOT NULL REFERENCES Status(id_status) ON DELETE RESTRICT, 
    id_agencia INTEGER NOT NULL REFERENCES Agencia(id_agencia) ON DELETE RESTRICT, 
    id_frota INTEGER NOT NULL REFERENCES Frota(id_frota) ON DELETE RESTRICT 
);

CREATE TABLE IF NOT EXISTS Manutencao (
    id_manutencao SERIAL PRIMARY KEY, 
    data_manutencao DATE NOT NULL,    
    tipo_manutencao VARCHAR(128) NOT NULL,
    custo_manutencao NUMERIC(12, 2) NOT NULL, 
    descricao_servicos VARCHAR(255) NOT NULL,
    quilometragem_entrada INTEGER NOT NULL DEFAULT 0,
    quilometragem_saida INTEGER NOT NULL DEFAULT 0,
    id_veiculo INTEGER NOT NULL REFERENCES Veiculo(id_veiculo) ON DELETE CASCADE 
);

CREATE TABLE IF NOT EXISTS Locacao (
    id_locacao SERIAL PRIMARY KEY,
    data_retirada DATE NOT NULL,
    hora_retirada TIME NOT NULL,
    data_prevista_devolucao DATE NOT NULL,
    hora_prevista_devolucao TIME NOT NULL,
    data_devolucao DATE, 
    hora_devolucao TIME, 
    valor_total NUMERIC(12, 2) NOT NULL DEFAULT 0.00,
    valor_adicionais NUMERIC(10, 2) NOT NULL DEFAULT 0.00,
    valor_diaria NUMERIC(10, 2) NOT NULL DEFAULT 0.00,
    quilometragem_retirada INTEGER NOT NULL DEFAULT 0,
    quilometragem_devolucao INTEGER,
    franquia_quilometragem INTEGER NOT NULL DEFAULT 0,
    local_retirada VARCHAR(128) NOT NULL,
    local_devolucao VARCHAR(128) NOT NULL,
    id_cliente INTEGER NOT NULL REFERENCES Cliente(id_cliente) ON DELETE RESTRICT, 
    id_agencia INTEGER NOT NULL REFERENCES Agencia(id_agencia) ON DELETE RESTRICT,
    id_veiculo INTEGER NOT NULL REFERENCES Veiculo(id_veiculo) ON DELETE RESTRICT 
);

CREATE TABLE IF NOT EXISTS LocacaoAdicional (
    id_locacao INTEGER NOT NULL REFERENCES Locacao(id_locacao) ON DELETE CASCADE,
    id_adicional INTEGER NOT NULL REFERENCES Adicional(id_adicional) ON DELETE RESTRICT,
    valor_negociado NUMERIC(10, 2) NOT NULL, 
    PRIMARY KEY (id_locacao, id_adicional)
);

CREATE TABLE IF NOT EXISTS Multas (
    id_multa SERIAL PRIMARY KEY,
    descricao_multa VARCHAR(255) NOT NULL,
    data_multa DATE NOT NULL,
    valor_multa NUMERIC(10, 2) NOT NULL,
    id_locacao INTEGER NOT NULL REFERENCES Locacao(id_locacao) ON DELETE CASCADE 
);