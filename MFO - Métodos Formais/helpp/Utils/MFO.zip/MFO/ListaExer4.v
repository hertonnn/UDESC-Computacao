Require Export Coq.Init.Logic.
Require Export Coq.Lists.List.
Import ListNotations.


(* Exercício 1*)
Theorem or_distributes_over_and : forall P Q R : Prop,
  P \/ (Q /\ R) <-> (P \/ Q) /\ (P \/ R).
Proof.
  intros. split.
  - intros [|eq]. split. left. apply H. left. apply H.
    split. right. destruct eq. apply H. right. destruct eq. apply H0.
  - intros. destruct H. destruct H. left. apply H.
    destruct H0. left. apply H0. right. split. apply H. apply H0. Qed.

(* Exercício 2*)

Theorem dist_exists_and : forall (X:Type) (P Q : X -> Prop),
  (exists x, P x /\ Q x) -> (exists x, P x) /\ (exists x, Q x).
Proof.
  intros. split. destruct H.
  - exists x. destruct H. apply H.
  - destruct H. exists x. destruct H. apply H0. Qed.

(* Exercício 3*)

Fixpoint In {A : Type} (x : A) (l : list A) : Prop :=
  match l with
  | [] => False
  | x' :: l' => x' = x \/ In x l'
  end.

Lemma In_map_iff :
  forall (A B : Type) (f : A -> B) (l : list A) (y : B),
    In y (map f l) <->
    exists x, f x = y /\ In x l.
Proof.
  intros. split.
  - induction l.
    + simpl. intros. destruct H.
    + simpl. intros. destruct H. exists a. split. apply H. left. reflexivity. apply IHl in H.
      destruct H. exists x. split. destruct H. apply H. right. destruct H. apply H0.
  - intros. induction l.
    + simpl. destruct H. destruct H. simpl in H0. destruct H0.
    + simpl. simpl in H. destruct H. destruct H. destruct H0. left. rewrite <- H0 in H. apply H.
      right. apply IHl. exists x. split. apply H. apply H0. Qed.

(* Exercício 4*)

Lemma In_app_iff : forall A l l' (a:A),
  In a (l++l') <-> In a l \/ In a l'.
Proof.
  intros. split.
  - induction l.
    + simpl. intros. right. apply H.
    + simpl. intros. destruct H.
      left. left. apply H. apply or_assoc. right. apply IHl in H. apply H.
  - induction l.
    + simpl. intros. destruct H. destruct H. apply H.
    + simpl. intros. destruct H. destruct H. left. apply H. right. apply IHl. left. apply H.
      right. apply IHl. right. apply H. Qed.

(* Exercício 5*)

Fixpoint All {T : Type} (P : T -> Prop) (l : list T) : Prop :=
  match l with
  | [] => True
  | (h :: t) => P h /\ All P t 
  end.

Lemma All_In :
  forall T (P : T -> Prop) (l : list T),
    (forall x, In x l -> P x) <->
    All P l.
Proof.
  intros. split.
  - induction l.
    + simpl. intros. split.
    + simpl. intros. split. apply H. left. split. apply IHl. intros. apply H. right. apply H0.
  - induction l.
    + simpl. intros. destruct H0.
    + simpl. intros. destruct H. destruct H0. rewrite <- H0. apply H. apply IHl. apply H1. apply H0. Qed.

(* Exercício 6*)

Theorem or_implies : forall (P Q : Prop), ~P \/ Q -> P -> Q.
Proof.
  intros. destruct H. unfold not in H. apply H in H0. destruct H0. apply H. Qed.

(* Exercício 7*)

Theorem implies_or_peirce : forall (P Q : Prop), (~P \/ Q) -> ((P -> Q) -> P) -> P.
Proof.
  intros. destruct H. unfold not in H. apply H in H0. destruct H0. intros. apply H in H1. destruct H1.
  apply H0. intros. apply H. Qed.

