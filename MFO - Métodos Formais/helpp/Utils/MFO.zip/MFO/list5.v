(* Exercícios - Expressões Regulares *)

Require Export Coq.Init.Logic.
Require Export Coq.Bool.Bool.
Require Export Coq.Lists.List.
Import ListNotations.

Inductive reg_exp {T : Type} : Type :=
  | EmptySet
  | EmptyStr
  | Char (t : T)
  | App (r1 r2 : reg_exp)
  | Union (r1 r2 : reg_exp)
  | Star (r : reg_exp).

Inductive exp_match {T} : list T -> reg_exp -> Prop :=
  | MEmpty : exp_match [] EmptyStr
  | MChar x : exp_match [x] (Char x)
  | MApp s1 re1 s2 re2
             (H1 : exp_match s1 re1)
             (H2 : exp_match s2 re2) :
             exp_match (s1 ++ s2) (App re1 re2)
  | MUnionL s1 re1 re2
                (H1 : exp_match s1 re1) :
                exp_match s1 (Union re1 re2)
  | MUnionR re1 s2 re2
                (H2 : exp_match s2 re2) :
                exp_match s2 (Union re1 re2)
  | MStar0 re : exp_match [] (Star re)
  | MStarApp s1 s2 re
                 (H1 : exp_match s1 re)
                 (H2 : exp_match s2 (Star re)) :
                 exp_match (s1 ++ s2) (Star re).

Notation "s =~ re" := (exp_match s re) (at level 80).

Fixpoint reg_exp_of_list {T} (l : list T) :=
  match l with
  | [] => EmptyStr
  | x :: l' => App (Char x) (reg_exp_of_list l')
  end.


(* Exercício 1*)
(* Dica pode ser necessário o uso da tática [generalize dependent]. *)

Lemma reg_exp_of_list_spec : forall T (s1 s2 : list T),
  s1 =~ reg_exp_of_list s2 <-> s1 = s2.
Proof.
  intros. generalize dependent s1. induction s2.
  - split.
    simpl. intros. inversion H. reflexivity.
    intros. simpl. rewrite H. apply MEmpty.
  - split.
    intros. simpl in H. inversion H. apply IHs2 in H4. inversion H3.
    rewrite H4. simpl. reflexivity.
    intros. simpl. rewrite H. assert (H1: a :: s2 = [a] ++ s2). { simpl. reflexivity. }
    rewrite H1. apply MApp. apply MChar. apply IHs2. reflexivity.
Qed.

Fixpoint re_not_empty {T : Type} (re : @reg_exp T) : bool :=
  match re with
    | EmptySet => false
    | EmptyStr => true
    | Char _ => true
    | App re1 re2 => andb (re_not_empty re1) (re_not_empty re2)
    | Union re1 re2 => orb (re_not_empty re1) (re_not_empty re2)
    | Star re1 => true
end.

(* Exercício 2*)
Lemma re_not_empty_correct : forall T (re : @reg_exp T),
  (exists s, s =~ re) <-> re_not_empty re = true.
Proof.
  intros. split.
  - intros. inversion H. induction H0.
    + simpl. reflexivity.
    + simpl. reflexivity.
    + simpl. rewrite IHexp_match1. rewrite IHexp_match2. simpl. reflexivity.
    exists s2. apply H0_0. exists s1. apply H0_.
    + simpl. destruct (re_not_empty re1). simpl. reflexivity. discriminate IHexp_match.
      exists s1. apply H0.
    + simpl. destruct (re_not_empty re1). simpl. reflexivity. simpl. apply IHexp_match.
      exists s2. apply H0.
    + simpl. reflexivity.
    + simpl. reflexivity.
  - intros. induction re.
    + simpl in H. discriminate H.
    + exists []. apply MEmpty.
    + exists [t]. apply MChar.
    + simpl in H. rewrite andb_true_iff in H. destruct H. destruct IHre1.
      apply H. destruct IHre2. apply H0. exists (x ++ x0). apply MApp. apply H1. apply H2.
    + simpl in H. rewrite orb_true_iff in H. destruct H. destruct IHre1.
      apply H. exists x. apply MUnionL. apply H0. destruct IHre2.
      apply H. exists x. apply MUnionR. apply H0.
    + exists []. apply MStar0.
Qed.

(* Exercício 3*)
Lemma MStar'' : forall T (s : list T) (re : reg_exp),
  s =~ Star re ->
  exists ss : list (list T),
    s = fold_right (@app T) [] ss
    /\ forall s', In s' ss -> s' =~ re.
Proof.
  intros. remember (Star re) as re' eqn:Heq. induction H.
  - inversion Heq.
  - inversion Heq.
  - inversion Heq.
  - inversion Heq.
  - inversion Heq.
  - inversion Heq. exists []. simpl. split. reflexivity. intros. destruct H.
  - inversion Heq. apply IHexp_match2 in Heq. destruct Heq. exists (s1 :: x). simpl. split.
    destruct H1. rewrite <- H1. reflexivity.
    intros. destruct H1. destruct H3. rewrite <- H3. rewrite H2 in H. apply H. apply H4. apply H3.
Qed. 
    