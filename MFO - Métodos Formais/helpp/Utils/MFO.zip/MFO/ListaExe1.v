Require Import Coq.Init.Nat.
(* Não deve ser importado nenhum novo arquivo
todas as definições devem estar neste arquivo *)


Fixpoint div2 (n:nat) : nat :=
  match n with
  | O => O
  | S O => O 
  | S (S n') => S (div2 n')  
end.  

Fixpoint sum (n : nat) : nat :=
  match n with
  | O => O
  | S n' => n + sum n'
  end.

Theorem plus_n_1 : forall (n : nat),
  n + 1 = S (n).
Proof.
 intros n. induction n as [| n' IHn'].
  - simpl. reflexivity.
  - simpl. rewrite IHn'. reflexivity. Qed.

Theorem plus_n_Sm : forall (n m:nat),
  n + S m = S (n + m).
Proof. 
  intros n m. induction n as [| n' IHn'].
  - simpl. reflexivity.
  - simpl. rewrite IHn'. reflexivity. Qed.

Theorem mult_2_n_plus : forall (n : nat),
  n + n = 2 * n.
Proof.
  intros n. induction n as [| n' IHn'].
  - simpl. reflexivity.
  - simpl. rewrite plus_n_Sm. rewrite IHn'. simpl. rewrite plus_n_Sm. reflexivity. Qed. 

Theorem mul2_div2 : forall n : nat,
  n = div2 (2 * n).
Proof.
  intros n. induction n as [| n' IHn'].
  - simpl. reflexivity.
  - rewrite <- mult_2_n_plus. simpl. rewrite plus_n_Sm. rewrite mult_2_n_plus. rewrite <- IHn'. reflexivity. Qed.

Theorem div2_mult2_plus: forall (n m : nat),
  n + div2 m = div2 (2 * n + m).
Proof.
  intros n m. induction n as [| n' IHn'].
  - simpl. reflexivity.
  - rewrite <- mult_2_n_plus. simpl. rewrite plus_n_Sm. rewrite mult_2_n_plus. simpl. rewrite IHn'. simpl. reflexivity. Qed.

Theorem mult_Sn_m : forall (n m : nat),
  S n * m = m + n * m.
Proof.
  intros n m. induction n as [| n' IHn'].
  - simpl. reflexivity.
  - simpl. reflexivity. Qed.

Theorem sum_Sn : forall n : nat,
  sum (S n) = S n + sum n.
Proof.
  intros n. induction n as [| n' IHn'].
  - simpl. reflexivity.
  - simpl. reflexivity. Qed.

Theorem add_0_r : forall n:nat, n + 0 = n.
Proof.
  intros n. induction n as [| n' IHn'].
  - reflexivity.
  - simpl. rewrite -> IHn'. reflexivity.  Qed.

Theorem comm_add : forall (n m : nat),
  n + m = m + n.
Proof.
  intros n m. induction n.
  - simpl. rewrite add_0_r. reflexivity.
  - simpl. rewrite plus_n_Sm. rewrite IHn. reflexivity. Qed.

Theorem add_assoc : forall n m p : nat,
  n + (m + p) = (n + m) + p.
Proof.
  intros n m p. induction n.
  - simpl. reflexivity.
  - simpl. rewrite IHn. reflexivity. Qed.

Theorem mult_n_Sm : forall (n m : nat),
  n * S m = n + n * m.
Proof.
  intros n m. induction n.
  - simpl. reflexivity.
  - simpl. rewrite IHn. rewrite comm_add. rewrite add_assoc.
  assert (H:  n * m + m = m + n * m).
  { rewrite comm_add. reflexivity. }
  rewrite <- add_assoc. rewrite H. rewrite add_assoc. reflexivity. Qed.

Theorem sum_n : forall n : nat,
  sum n = div2 (n * (n + 1)).
Proof.
  intros n. induction n as [| n' IHn'].
  - simpl. reflexivity.
  - rewrite plus_n_1. simpl.
    rewrite IHn'.
    rewrite plus_n_1.
    rewrite div2_mult2_plus.
    rewrite <- mult_2_n_plus.
    rewrite mult_n_Sm. 
    rewrite mult_n_Sm. 
    rewrite mult_n_Sm.
    rewrite add_assoc.
    rewrite add_assoc.
    rewrite add_assoc.
    reflexivity. Qed. 